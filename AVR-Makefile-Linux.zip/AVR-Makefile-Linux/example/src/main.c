#include <avr/io.h>

void _func();

int main(void)
{
	_func();
}
