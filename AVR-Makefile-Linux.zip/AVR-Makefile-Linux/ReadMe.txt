﻿After a lot of trouble I've managed to make c and assembly work together on Linux for AVR platform. 
I have made a generic Makefile suite to make things easier. C++ not implemented yet. But I guess its enough to start on Linux.

So I am giving the Linux users that opportunity to work with AVR family by GNU tool-chain. Simply follow the steps below and enjoy Linux …. :)

Steps :
1. First install gcc-avr , binutils-avr , avr-libc , avrdude from your Linux's software repository .
2. Download the Makefile suite. You will find it on the group's Files option. It “AVR-Makefile-Linux.zip” . Extract it anywhere you like.
3. Create a folder for your project(i.e  AVR-Project )
4. Create another folder in the project folder(i.e AVR-Project/src) . Its your source folder. Create and save any source file for your project in this folder. 
5. Now copy all the files from final-avr-makefiles from your extracted directory in your project folder(i.e in the AVR-project folder)
6. Now edit the Makefile.config according to your project. Please see the example given with it.
7. Your must fill up the TARGET, SRC_FOLDER, BIN_FOLDER, MCU to build your project successfully. Again I am asking to refer to the example.
8. After you create your sources run the following commands from your project folder to perform specific operation :
make <to build your project>
make clean <to clean up your binaries>
make program <to burn the hex file>
make program-all <to burn hex, lfuse, hfuse, efuse>
make lfuse <to burn the low fuse only>
make hfuse <to burn the high fuse only>
make efuse <to burn the extended fuse only>

(NOTE:  Same makefiles can be used for Windows. Just need tocomment out the SUDO variable from Makefile.config)
