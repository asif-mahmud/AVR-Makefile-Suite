#include <avr/io.h>
#include <util/delay.h>
#include <avr/eeprom.h>

#define d _delay_ms(100)

uint32_t EEMEM var = 0;

int main(void)
{
	DDRC = 0xff;
	
	while(1){
	PORTC = 0xff;
	d;
	PORTC = 0;
	d;}	
}
